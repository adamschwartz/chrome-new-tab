## Chrome New Tab

### Installation
`git clone` this repo. Go to Chrome Settings > Extensions ([chrome://extensions](chrome://extensions)). Click *Load unpacked extension* and choose this repo. Disable the extension to switch back to the original Chrome New Tab page.

### Credit

Based on [tech-no-crat](https://github.com/tech-no-crat)'s [chrome-newtab-minimalism](https://github.com/tech-no-crat/chrome-newtab-minimalism).